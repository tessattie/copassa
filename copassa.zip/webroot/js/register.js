$(document).ready(function(){
	console.log(products);
})